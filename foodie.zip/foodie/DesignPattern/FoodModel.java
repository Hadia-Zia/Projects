import java.util.ArrayList;
import java.util.List;

public class FoodModel {
    private List<String> foodItems;

    public FoodModel() {
        this.foodItems = new ArrayList<>();
    }

    public void addFoodItem(String item) {
        foodItems.add(item);
    }

    public List<String> getFoodItems() {
        return new ArrayList<>(foodItems); 
    }
}

