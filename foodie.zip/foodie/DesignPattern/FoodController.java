import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FoodController {
    private FoodModel model;
    private FoodView view;

    public FoodController(FoodModel model, FoodView view) {
        this.model = model;
        this.view = view;

        view.addActionListenerToAddFoodItem(new AddFoodItemListener());
        updateView();
    }

    private void updateView() {
        List<String> foodItems = model.getFoodItems();
        view.update(foodItems);
    }

    private class AddFoodItemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String newItem = JOptionPane.showInputDialog("Enter a food item:");
            if (newItem != null && !newItem.isEmpty()) {
                model.addFoodItem(newItem);
                updateView();
            }
        }
    }
}
