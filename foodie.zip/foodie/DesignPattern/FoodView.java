import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FoodView {
    private JFrame frame;
    private JTextArea foodListArea;

    public FoodView() {
        frame = new JFrame("Foodie Website");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        foodListArea = new JTextArea();
        foodListArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(foodListArea);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    public void update(List<String> foodItems) {
        StringBuilder sb = new StringBuilder();
        for (String item : foodItems) {
            sb.append(item).append("\n");
        }
        foodListArea.setText(sb.toString());
    }

    public void display() {
        frame.setVisible(true);
    }
}
