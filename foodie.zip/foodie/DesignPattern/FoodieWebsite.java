public class FoodieWebsite {
    public static void main(String[] args) {
        FoodModel model = new FoodModel();
        FoodView view = new FoodView();
        FoodController controller = new FoodController(model, view);

        // Display initial menu
        controller.displayMenu();

        // Add a new food item
        controller.addFoodItem();

        // Display updated menu
        controller.displayMenu();
    }
}
