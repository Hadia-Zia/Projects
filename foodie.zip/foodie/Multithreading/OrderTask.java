public class OrderTask implements Runnable {

    private final String userName;
    private final String foodItem;
    private final int quantity;

    public OrderTask(String userName, String foodItem, int quantity) {
        this.userName = userName;
        this.foodItem = foodItem;
        this.quantity = quantity;
    }

    @Override
    public void run() {
        System.out.println(userName + " is placing an order for " + quantity + " " + foodItem + "(s).");

        // Simulate some processing time for order fulfillment
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(userName + "'s order for " + quantity + " " + foodItem + "(s) is ready!");
    }
}
