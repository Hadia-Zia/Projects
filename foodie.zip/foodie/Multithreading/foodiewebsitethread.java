import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class foodiewebsitethread{

    public static void main(String[] args) {
        // Create a thread pool with 5 threads
        ExecutorService executorService = Executors.newFixedThreadPool(5);

        // Simulate multiple users placing orders concurrently
        for (int i = 1; i <= 10; i++) {
            Runnable orderTask = new OrderTask("User " + i, "Pizza", 2);
            executorService.execute(orderTask);
        }

        // Shutdown the thread pool
        executorService.shutdown();
    }
}

