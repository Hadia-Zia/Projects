<?php
include 'config.php';

if(isset($_POST['submit'])){
   $id = mysqli_real_escape_string($conn, $_POST['id']);
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, $_POST['password']);
   $cpass = mysqli_real_escape_string($conn, $_POST['cpassword']);
   $Phone =  mysqli_real_escape_string($conn, $_POST['Phone']);
   
   

   // Validate User ID
   if(!preg_match('/^(?=.*[a-z])(?=.*[0-9])[a-z0-9]{6,}$/i', $id)){
      $message[] = 'User ID should contain minimum 6 characters with both alphabets and numbers. Special characters are not allowed.';
   } else {
      $select = mysqli_query($conn, "SELECT * FROM user_form WHERE id = '$id'") or die('Query failed');

      if(mysqli_num_rows($select) > 0){
         $message[] = 'User ID already exists'; 
      }else{
         // Validate Password
         if(!preg_match('/^[a-zA-Z0-9]{8}$/', $pass)){
            $message[] = 'Password should be exactly 8 characters long. Special characters are not allowed.';
         } else {
            // Rest of the code for email validation, confirm password validation, image size validation, and database insertion
            if($pass != $cpass){
               $message[] = 'Confirm password not matched!';
            
            }else{
               $insert = mysqli_query($conn, "INSERT INTO user_form (id,name, email, password, Phone) VALUES('$id','$name', '$email', '$pass', '$Phone')") or die('Query failed');

               
            }
         }
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head><title>register</title>
<link rel="icon" href="logo.png" type="image/png">

<!-- Rest of your code -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="assets/css/style.css">
<style>
body {
  background-color: #f2f2f2;
  font-family: Arial, sans-serif;
}

.form-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form-container h3 {
  text-align: center;
  margin-bottom: 20px;
}

.form-container input[type="text"],
.form-container input[type="email"],
.form-container input[type="password"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.form-container input[type="submit"] {
  width: 100%;
  padding: 10px;
  background-color: #4caf50;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.form-container p {
  text-align: center;
  margin-top: 15px;
}

.form-container a {
  color: #4caf50;
}

.message {
  color: red;
  margin-bottom: 10px;
}
/* media query */
@media (max-width: 480px) {
  .form-container {
    padding: 10px;
  }
}

</style>
</head>
<body>
   
<div class="form-container">
   <form action="" method="post" enctype="multipart/form-data">
      <h3>Register Now</h3>
      <?php
      if(isset($message)){
         foreach($message as $msg){
            echo '<div class="message">'.$msg.'</div>';
         }
      }
      ?>
      
      <br>
      <h6 align="left">ID:</h6>
      <input id="slideOutButton" type="text" name="id" placeholder="Enter User ID" class="box" required>
      <h6 align="left">Name:</h6>
      <input type="text" name="name" placeholder="Enter Username" class="box" required>
      <h6 align="left">Email:</h6>
      <input type="email" name="email" placeholder="Enter Email" class="box" required>
      <h6 align="left">Password:</h6>
      <input type="password" name="password" placeholder="Enter Password" class="box" required>
      <input type="password" name="cpassword" placeholder="Confirm Password" class="box" required>
      
      <h6 align="left">Phone</6>
      <input type="text" name="Phone" class="box" placeholder="+92" required>
      
      
      <input type="submit" name="submit" value="Register Now" class="btn">
      <p>Already have an account? <a href="login.php">Login Now</a></p>
   </form>
   <script>
   document.getElementById("slideOutButton").addEventListener("click", function() {
   document.getElementById("slideOutMessage").style.right = "0";
});

document.getElementById("closeButton").addEventListener("click", function() {
   document.getElementById("slideOutMessage").style.right = "-250px";
});
</script>
</div>

</body>
</html>

