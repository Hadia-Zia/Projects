<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Foodie - Supper delicious Burger in town!</title>

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- 
    - custom css link
  -->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">


  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&family=Rubik:wght@400;500;600;700&family=Shadows+Into+Light&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-banner.png" media="min-width(768px)">
  <link rel="preload" as="image" href="./assets/images/hero-banner-bg.png" media="min-width(768px)">
  <link rel="preload" as="image" href="./assets/images/hero-bg.jpg">

</head>
<style>
  .modal {
  display: none;
  position: fixed;
  z-index: 999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
  background-color: #fefefe;
  margin: 10% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 300px;
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
  cursor: pointer;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

.login-button {
  /* Your login button styles here */
}

.login-form {
  text-align: center;
}

.login-form h2 {
  margin-bottom: 20px;
}

.login-form input {
  display: block;
  width: 100%;
  margin-bottom: 10px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.login-form button[type="submit"] {
  display: block;
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.login-form button[type="submit"]:hover {
  background-color: #45a049;
}

  </style>
<body id="top">

    <!-- 
      - #HEADER
    -->
  
    <header class="header" data-header>
      <div class="container">
  
          <h1>
            <a href="#" class="logo">Foodie<span class="span">.</span></a>
          </h1>
  
          <nav class="navbar" data-navbar>
            <ul class="navbar-list">
  
              <li class="nav-item">
                <a href="#home" class="navbar-link" data-nav-link>Home</a>
              </li>
  
              <li class="nav-item">
                <a href="aboutus.php" class="navbar-link" data-nav-link>About Us</a>
              </li>
  
              <li class="nav-item">
                <a href="shop.php" class="navbar-link" data-nav-link>Shop</a>
              </li>
  
              <li class="nav-item">
                <a href="blog.php" class="navbar-link" data-nav-link>Blog</a>
              </li>
  
              <li class="nav-item">
                <a href="contact.php" class="navbar-link" data-nav-link>Contact Us</a>
              </li>
              <li class="nav-item">
              <i class="fas fa-user"></i>
  
            </li>
              
            </ul>
          </nav>
  
        <div class="header-btn-group">
          <button class="search-btn" aria-label="Search" data-search-btn>
            <ion-icon name="search-outline"></ion-icon>
          </button>

  
          <button class="nav-toggle-btn" aria-label="Toggle Menu" data-menu-toggle-btn>
            <span class="line top"></span>
            <span class="line middle"></span>
            <span class="line bottom"></span>
          
          </button>
          </div></header>
          <style>
            body, html {
              height: 100%;
              margin: 0;
              font-family: Arial, Helvetica, sans-serif;
            }
            
            .hero-image {
              background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("banner-1.jpg");
              height: 50%;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;
              position: relative;
            }
            
            .hero-text {
              text-align: center;
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              color: white;
            }
            
            .hero-text button {
              border: none;
              outline: 0;
              display: inline-block;
              padding: 10px 25px;
              color: black;
              background-color: #ddd;
              text-align: center;
              cursor: pointer;
            }
            
            .hero-text button:hover {
              background-color: #555;
              color: white;
            }
            </style>
         <div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size:50px">FOODIE</h1>
    <p>Shop</p><br>
    <a href="index.php" class="btn btn-hover"><h1>Home</h1></a>
  </div>
</div>

<section class="section food-menu" id="food-menu">
    <div class="container">

      <p class="section-subtitle">Popular Dishes</p>

      <h2 class="h2 section-title">
        Our Delicious <span class="span">Foods</span>
      </h2>

      <p class="section-text">
        Food is any substance consumed to provide nutritional support for an organism.
      </p>

      <ul class="fiter-list">

        <li>
          <button class="filter-btn  active">All</button>
        </li>

        <li>
          <button class="filter-btn">Pizza</button>
        </li>

        <li>
          <button class="filter-btn">Burger</button>
        </li>

        <li>
          <button class="filter-btn">Drinks</button>
        </li>

        <li>
          <button class="filter-btn">Sandwich</button>
        </li>

      </ul>

      <ul class="food-menu-list">

        <li>
          <div class="food-menu-card">

            <div class="card-banner">
              <img src="./assets/images/food-menu-1.png" width="300" height="300" loading="lazy"
                alt="Fried Chicken Unlimited" class="w-100">

              <div class="badge">-15%</div>

              <button class="btn food-menu-btn">Order Now</button>
            </div>

            <div class="wrapper">
              <p class="category">Chicken</p>

              <div class="rating-wrapper">
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
              </div>
            </div>

            <h3 class="h3 card-title">Fried Chicken Unlimited</h3>

            <div class="price-wrapper">

              <p class="price-text">Price:</p>

              <data class="price">$49.00</data>

              <del class="del" value="69.00">$69.00</del>

            </div>

          </div>
        </li>

        <li>
          <div class="food-menu-card">

            <div class="card-banner">
              <img src="./assets/images/food-menu-2.png" width="300" height="300" loading="lazy"
                alt="Burger King Whopper" class="w-100">

              <div class="badge">-10%</div>

              <button class="btn food-menu-btn">Order Now</button>
            </div>

            <div class="wrapper">
              <p class="category">Noddles</p>

              <div class="rating-wrapper">
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
              </div>
            </div>

            <h3 class="h3 card-title">Burger King Whopper</h3>

            <div class="price-wrapper">

              <p class="price-text">Price:</p>

              <data class="price" value="29.00">$29.00</data>

              <del class="del">$39.00</del>

            </div>

          </div>
        </li>

        <li>
          <div class="food-menu-card">

            <div class="card-banner">
              <img src="./assets/images/food-menu-3.png" width="300" height="300" loading="lazy"
                alt="White Castle Pizzas" class="w-100">

              <div class="badge">-25%</div>

              <button class="btn food-menu-btn">Order Now</button>
            </div>

            <div class="wrapper">
              <p class="category">Pizzas</p>

              <div class="rating-wrapper">
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
              </div>
            </div>

            <h3 class="h3 card-title">White Castle Pizzas</h3>

            <div class="price-wrapper">

              <p class="price-text">Price:</p>

              <data class="price" value="49.00">$49.00</data>

              <del class="del">$69.00</del>

            </div>

          </div>
        </li>

        <li>
          <div class="food-menu-card">

            <div class="card-banner">
              <img src="./assets/images/food-menu-4.png" width="300" height="300" loading="lazy"
                alt="Bell Burrito Supreme" class="w-100">

              <div class="badge">-20%</div>

              <button class="btn food-menu-btn">Order Now</button>
            </div>

            <div class="wrapper">
              <p class="category">Burrito</p>

              <div class="rating-wrapper">
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
              </div>
            </div>

            <h3 class="h3 card-title">Bell Burrito Supreme</h3>

            <div class="price-wrapper">

              <p class="price-text">Price:</p>

              <data class="price" value="59.00 ">$59.00</data>

              <del class="del">$69.00</del>

            </div>

          </div>
        </li>

        <li>
          <div class="food-menu-card">

            <div class="card-banner">
              <img src="./assets/images/food-menu-5.png" width="300" height="300" loading="lazy"
                alt="Kung Pao Chicken BBQ" class="w-100">

              <div class="badge">-5%</div>

              <button class="btn food-menu-btn">Order Now</button>
            </div>

            <div class="wrapper">
              <p class="category">Nuggets</p>

              <div class="rating-wrapper">
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
              </div>
            </div>

            <h3 class="h3 card-title">Kung Pao Chicken BBQ</h3>

            <div class="price-wrapper">

              <p class="price-text">Price:</p>

              <data class="price" value="49.00">$49.00</data>

              <del class="del">$69.00</del>

            </div>

          </div>
        </li>

        <li>
          <div class="food-menu-card">

            <div class="card-banner">
              <img src="./assets/images/food-menu-6.png" width="300" height="300" loading="lazy"
                alt="Wendy's Chicken" class="w-100">

              <div class="badge">-15%</div>

              <button class="btn food-menu-btn">Order Now</button>
            </div>

            <div class="wrapper">
              <p class="category">Chicken</p>

              <div class="rating-wrapper">
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
                <ion-icon name="star"></ion-icon>
              </div>
            </div>

            <h3 class="h3 card-title">Wendy's Chicken</h3>

            <div class="price-wrapper">

              <p class="price-text">Price:</p>

              <data class="price" value="49.00">$49.00</data>

              <del class="del">$69.00</del>

            </div>

          </div>
        </li>

      </ul>


    </div>
  </section>





  <!-- 
    - #CTA
  -->

  <section class="section section-divider white cta" style="background-image: url('./assets/images/hero-bg.jpg')">
    <div class="container">

      <div class="cta-content">

        <h2 class="h2 section-title">
          The Foodie Have Excellent Of
          <span class="span">Quality Burgers!</span>
        </h2>

        <p class="section-text">
          The restaurants in Hangzhou also catered to many northern Chinese who had fled south from Kaifeng during
          the Jurchen
          invasion of the 1120s, while it is also known that many restaurants were run by families.
        </p>

        <button class="btn btn-hover">Order Now</button>
      </div>

      <figure class="cta-banner">
        <img src="./assets/images/cta-banner.png" width="700" height="637" loading="lazy" alt="Burger"
          class="w-100 cta-img">

        <img src="./assets/images/sale-shape.png" width="216" height="226" loading="lazy"
          alt="get up to 50% off now" class="abs-img scale-up-anim">
      </figure>

    </div>
  </section>

  <!-- 
        - #DELIVERY
      -->

      <section class="section section-divider gray delivery">
        <div class="container">

          <div class="delivery-content">

            <h2 class="h2 section-title">
              A Moments Of Delivered On <span class="span">Right Time</span> & Place
            </h2>

            <p class="section-text">
              The restaurants in Hangzhou also catered to many northern Chinese who had fled south from Kaifeng during
              the Jurchen
              invasion of the 1120s, while it is also known that many restaurants were run by families.
            </p>

            <button class="btn btn-hover">Order Now</button>
          </div>

          <figure class="delivery-banner">
            <img src="./assets/images/delivery-banner-bg.png" width="700" height="602" loading="lazy" alt="clouds"
              class="w-100">

            <img src="./assets/images/delivery-boy.svg" width="1000" height="880" loading="lazy" alt="delivery boy"
              class="w-100 delivery-img" data-delivery-boy>
          </figure>

        </div>
      </section>

          </body>
          </html>