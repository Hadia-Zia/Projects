public class FoodieWebsite {

    public double calculateTotalPrice(double itemPrice, int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity must be non-negative");
        }
        return itemPrice * quantity;
    }
}

