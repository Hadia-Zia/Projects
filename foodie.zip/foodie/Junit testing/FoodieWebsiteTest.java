import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class FoodieWebsiteTest {

    @Test
    public void testCalculateTotalPrice() {
        FoodieWebsite foodieWebsite = new FoodieWebsite();

        // Test case 1: Normal case
        assertEquals(20.0, foodieWebsite.calculateTotalPrice(5.0, 4));

        // Test case 2: Quantity is zero
        assertEquals(0.0, foodieWebsite.calculateTotalPrice(5.0, 0));

        // Test case 3: Quantity is negative, should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            foodieWebsite.calculateTotalPrice(5.0, -2);
        });
    }

)

