<?php
// localhost , username , password , databasename
$conn = mysqli_connect('localhost','root','','foodie') or die('connection failed');

?>