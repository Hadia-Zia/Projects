<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/style.css">
  <title>About Us</title>
</head>

<body id="top">

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

        <h1>
          <a href="#" class="logo">Foodie<span class="span">.</span></a>
        </h1>

        <nav class="navbar" data-navbar>
          <ul class="navbar-list">

            <li class="nav-item">
              <a href="index.php" class="navbar-link" data-nav-link>Home</a>
            </li>

            <li class="nav-item">
              <a href="#about" class="navbar-link" data-nav-link>About Us</a>
            </li>

            <li class="nav-item">
              <a href="shop.php" class="navbar-link" data-nav-link>Shop</a>
            </li>

            <li class="nav-item">
              <a href="blog.php" class="navbar-link" data-nav-link>Blog</a>
            </li>

            <li class="nav-item">
              <a href="contact.php" class="navbar-link" data-nav-link>Contact Us</a>
            </li>
            <li class="nav-item">
            <i class="fas fa-user"></i>

          </li>
            
          </ul>
        </nav>

      <div class="header-btn-group">
        <button class="search-btn" aria-label="Search" data-search-btn>
          <ion-icon name="search-outline"></ion-icon>
        </button>

        <button class="nav-toggle-btn" aria-label="Toggle Menu" data-menu-toggle-btn>
          <span class="line top"></span>
          <span class="line middle"></span>
          <span class="line bottom"></span>
        
        </button>
        </div></header>
<style>
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("banner-1.jpg");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
</style>
</head>
<body>

<div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size:50px">FOODIE</h1>
    <p>ABOUT US</p><br>
    <a href="index.php" class="btn btn-hover"><h1>Home</h1></a>
  </div>
</div>
  <main>
    <section class="section">
      <div class="container">
        <h1 class="h1">About Us</h1>
        <P>The purpose of this website is to outline the development of a foodie website, Foodie, dedicated to food. Foodie will serve as a platform to share and discover recipes, cooking tips, restaurant reviews, and foster a vibrant online foodie community. This project aims to secure the necessary resources and approvals for the creation of this website.

        </P>
      
        <p>
          The Foodie website presents a unique opportunity to create a vibrant online community for food enthusiasts. It aims to provide culinary inspiration, foster community interaction, and enhance cooking skills. This proposal seeks support and resources to bring this initiative to life and contribute to the global culinary culture. 
        </p>
        <p>
          Foodie aims to be the go-to platform for foodies, providing a seamless user experience with features like recipe sharing, a culinary blog, restaurant reviews, and cooking challenges. The objective is to foster a dynamic foodie community and offer valuable content to users.
        </p>
      </div>
    </section>
  </main>

  <footer>
  &copy; 2023 Foodie Website. All rights reserved.
  </footer>
</body>

</html>
