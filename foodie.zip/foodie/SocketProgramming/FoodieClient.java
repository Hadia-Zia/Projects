import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class FoodieClient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to the server.");

            while (true) {
                System.out.println("1. Get Food Items");
                System.out.println("2. Add Food Item");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1:
                        // Send request to get food items
                        writer.write("GET_FOOD_ITEMS\n");
                        writer.flush();

                        // Receive and display food items from the server
                        String foodItem;
                        while (!(foodItem = reader.readLine()).equals("END")) {
                            System.out.println(foodItem);
                        }
                        break;

                    case 2:
                        // Send request to add a new food item
                        System.out.print("Enter the food item: ");
                        String newItem = scanner.nextLine();
                        writer.write("ADD_FOOD_ITEM:" + newItem + "\n");
                        writer.flush();
                        break;

                    case 3:
                        // Send exit command to the server
                        writer.write("EXIT\n");
                        writer.flush();
                        return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

