import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class FoodieServer {
    private static final int PORT = 12345;

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server is running and waiting for connections...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Handle client connection in a separate thread
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))) {

            // Initialize the model
            FoodModel model = new FoodModel();

            String input;
            while ((input = reader.readLine()) != null) {
                if ("EXIT".equals(input)) {
                    break;
                } else if ("GET_FOOD_ITEMS".equals(input)) {
                    // Send the list of food items to the client
                    List<String> foodItems = model.getFoodItems();
                    for (String item : foodItems) {
                        writer.write(item + "\n");
                    }
                    writer.write("END\n");
                    writer.flush();
                } else if (input.startsWith("ADD_FOOD_ITEM:")) {
                    // Add a new food item to the model
                    String newItem = input.substring("ADD_FOOD_ITEM:".length());
                    model.addFoodItem(newItem);
                    System.out.println("Added food item: " + newItem);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

